intro = {
    "game_intro": ">>>>>>>>>>>>>> LET THE DICE ROLLIN\' <<<<<<<<<<<<<<\nSo You want to force your luck by rolling a dice.\nHere is your chance to leave it for Fortuna!\n Can we go?\n",

}

result = {
    "number_rolled": "Fortuna rolled a {0} for you\n ",
    "satisfied":"Are you satisfied?",
    "sayno": "Don\'t you want to roll a dice?\n",
    "false": "What? Type an 'y' or 'n'. Not that hard.\n",
    "no_play": "Are you sure?\n",
}

numbers = {
    "1" : "-------\n|     |\n|  o  |\n|     |\n-------\n",
    "2" : "-------\n| o   |\n|     |\n|   o |\n-------\n",
    "3" : "-------\n| o   |\n|  o  |\n|   o |\n-------\n",
    "4" : "-------\n| o o |\n|     |\n| o o |\n-------\n",
    "5" : "-------\n| o o |\n|  o  |\n| o o |\n-------\n",
    "6" : "-------\n| o o |\n| o o |\n| o o |\n-------\n",
}
